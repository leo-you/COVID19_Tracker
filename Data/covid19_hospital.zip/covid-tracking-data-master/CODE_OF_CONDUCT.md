# The COVID Tracking Project Code of Conduct

The COVID Tracking Project follows the [code of conduct defined in this document](https://github.com/COVID19Tracking/code-of-conduct/blob/master/CODE_OF_CONDUCT.md).